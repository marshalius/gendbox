class LinearRegression:
    